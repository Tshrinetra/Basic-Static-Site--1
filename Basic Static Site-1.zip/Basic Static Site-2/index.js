const express = require("express");
const app =express();
app.use(express.urlencoded({extended:true}))
app.use(express.static(__dirname  + "/public"));
app.get("/",(req,res)=>{
res.sendFile(__dirname + "/home.html");
})
app.listen(3000,(err)=>{
      if(err)
            console.log("unable to start server")
      else
      console.log("Server started");
})

